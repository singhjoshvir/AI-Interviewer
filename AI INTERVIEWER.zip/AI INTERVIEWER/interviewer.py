import os
import random
from openai import OpenAI
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

class Interviewer:
    def __init__(self):
        self.openai_key = os.getenv("OPENAI_API_KEY")
        self.gemini_key = os.getenv("GEMINI_API_KEY")
        self.provider = None
        self.client = None
        
        # Initialize Provider
        if self.openai_key and self.openai_key.startswith("sk-") and "paste_your_key" not in self.openai_key:
            self.provider = "openai"
            self.client = OpenAI(api_key=self.openai_key)
            print("LOG: Using OpenAI Provider")
        elif self.gemini_key and "paste_your_key" not in self.gemini_key:
            self.provider = "gemini"
            genai.configure(api_key=self.gemini_key)
            self.client = genai.GenerativeModel('gemini-pro')
            print("LOG: Using Gemini Provider")
        else:
            self.provider = "offline"
            print("LOG: Using Offline/Demo Provider")

        self.conversation_history = []
        self.offline_step = 0
        self.system_prompt = self._get_master_prompt()
        
        # Initial context setting
        if self.provider == "openai":
            self.conversation_history.append({"role": "system", "content": self.system_prompt})
        elif self.provider == "gemini":
            self.chat_session = self.client.start_chat(history=[
                {"role": "user", "parts": [self.system_prompt]},
                {"role": "model", "parts": ["Understood. I am ready to conduct the interview based on your instructions."]}
            ])

    def _get_master_prompt(self):
        return """You are an experienced technical and HR interviewer with 10+ years of industry experience.
Your task is to conduct a text-based interview using reasoning and contextual understanding only.
INTERVIEW RULES:
1. Ask one question at a time.
2. Adjust difficulty based on the candidate’s previous answer.
3. Be professional but conversational.
4. Do NOT reveal evaluation criteria.

Phases: Intro -> Tech -> Problem Solving -> Communication.
At the end, if asked to evaluate, provide a scored report.
Start by asking the candidate to introduce themselves."""

    def get_response(self, user_input):
        try:
            # --- 1. OPENAI HANDLER ---
            if self.provider == "openai":
                self.conversation_history.append({"role": "user", "content": user_input})
                response = self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=self.conversation_history,
                    temperature=0.7
                )
                bot_reply = response.choices[0].message.content
                self.conversation_history.append({"role": "assistant", "content": bot_reply})
                return bot_reply

            # --- 2. GEMINI HANDLER ---
            elif self.provider == "gemini":
                response = self.chat_session.send_message(user_input)
                return response.text

            # --- 3. OFFLINE FALLBACK ---
            else:
                return self._offline_logic(user_input)

        except Exception as e:
            print(f"Error with {self.provider}: {e}")
            # Automatically switch to Offline Mode for this and future requests
            self.provider = "offline"
            return f"[System: Connection to {e.__class__.__name__} failed. Switching to Offline Mode.]\n\n" + self._offline_logic(user_input)

    def _offline_logic(self, user_input):
        self.offline_step += 1
        user_input = user_input.lower()
        
        # Simple scripted flow for demo purposes
        if self.offline_step == 1:
            return "Hello! Welcome to the AI Interview. I'm running in Offline Mode (no API key detected). Let's start! Can you tell me a bit about your background?"
        
        if "python" in user_input or "code" in user_input or "developer" in user_input:
            return "That's great. Since you mentioned development, can you explain the difference between a list and a tuple in Python?"
        
        if "list" in user_input and "tuple" in user_input:
            return "Good explanation. Now, let's move to a problem-solving scenario. If your production server suddenly goes down with a 500 error, what are your first three debugging steps?"
        
        if "logs" in user_input or "server" in user_input or "check" in user_input:
            return "Solid approach. Checking logs is crucial. Now, how do you handle conflict with a team member who disagrees with your technical design?"
        
        if "generate" in user_input or "report" in user_input or "evaluate" in user_input or "end" in user_input:
            return self.generate_evaluation()

        # Generic responses if no keywords match
        generics = [
            "Interesting. Can you elaborate on that?",
            "I see. Could you give me an example?",
            "Thank you. Let's move on. What defines good code quality for you?",
            "Understood. Why do you want to work in this role?"
        ]
        return random.choice(generics)

    def reset_interview(self):
        self.__init__() # Re-init to clear state
        if self.provider == "offline":
             # Force first message
             self.offline_step = 0

    def generate_evaluation(self):
        if self.provider == "offline":
            return """**OFFLINE EVALUATION REPORT**
*Note: This is a simulation because no API key was provided.*

- **Technical Knowledge**: 8/10 (Inferred from keywords)
- **Problem Solving**: 7/10
- **Communication**: 9/10

**Verdict**: READY (Simulation)
Please add an API Key (OpenAI or Gemini) for a real adaptive evaluation."""
        
        prompt = "The interview is over. Please generate the detailed evaluation report now."
        return self.get_response(prompt)
