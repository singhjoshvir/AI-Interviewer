document.addEventListener('DOMContentLoaded', () => {
    const chatHistory = document.getElementById('chat-history');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const endBtn = document.getElementById('end-interview-btn');
    const resetBtn = document.getElementById('reset-btn');

    // Auto-resize textarea
    userInput.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
        if (this.value === '') {
            this.style.height = 'auto';
        }
    });

    // Send message on Enter (but Shift+Enter for newline)
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    sendBtn.addEventListener('click', sendMessage);

    endBtn.addEventListener('click', async () => {
        if (!confirm('Are you sure you want to end the interview and generate the evaluation?')) return;

        appendMessage('system', 'Generating evaluation report... this may take a moment.');
        try {
            const response = await fetch('/api/end', { method: 'POST' });
            const data = await response.json();
            appendMessage('ai', data.response); // The evaluation report
            endBtn.disabled = true;
            userInput.disabled = true;
        } catch (error) {
            appendMessage('error', 'Error generating evaluation: ' + error);
        }
    });

    resetBtn.addEventListener('click', async () => {
        if (!confirm('Start a new interview? Current progress will be lost.')) return;

        try {
            const response = await fetch('/api/reset', { method: 'POST' });
            const data = await response.json();

            // Clear history and show greeting
            chatHistory.innerHTML = '';
            appendMessage('ai', data.response);

            // Re-enable controls
            endBtn.disabled = false;
            userInput.disabled = false;
            userInput.focus();
        } catch (error) {
            console.error('Error resetting:', error);
        }
    });

    async function sendMessage() {
        const text = userInput.value.trim();
        if (!text) return;

        appendMessage('user', text);
        userInput.value = '';
        userInput.style.height = 'auto';

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text })
            });
            const data = await response.json();

            if (data.error) {
                appendMessage('error', data.error);
            } else {
                appendMessage('ai', data.response);
            }
        } catch (error) {
            appendMessage('error', 'Network error. Please try again.');
        }
    }

    function appendMessage(role, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message`;

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';

        // Simple markdown parsing for the evaluation report (bolding, lists)
        let formattedText = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
            .replace(/\n/g, '<br>'); // Newlines

        contentDiv.innerHTML = formattedText;

        messageDiv.appendChild(contentDiv);
        chatHistory.appendChild(messageDiv);

        // Scroll to bottom
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
});
