from flask import Flask, render_template, request, jsonify
from interviewer import Interviewer
import os

app = Flask(__name__)
interviewer = Interviewer()

@app.route('/')
def home():
    # Start a fresh interview on page load
    interviewer.reset_interview()
    initial_greeting = interviewer.get_response("Hello, I am ready for the interview.")
    return render_template('index.html', initial_greeting=initial_greeting)

@app.route('/api/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    if not user_input:
        return jsonify({"error": "No message provided"}), 400
    
    response = interviewer.get_response(user_input)
    return jsonify({"response": response})

@app.route('/api/end', methods=['POST'])
def end_interview():
    evaluation = interviewer.generate_evaluation()
    return jsonify({"response": evaluation})

@app.route('/api/reset', methods=['POST'])
def reset():
    interviewer.reset_interview()
    initial_greeting = interviewer.get_response("Hello, I am ready for the interview.")
    return jsonify({"response": initial_greeting})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
